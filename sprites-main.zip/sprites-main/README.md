using sprites for pokedia bot
